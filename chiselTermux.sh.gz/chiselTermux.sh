echo "Vpn_x123"
apt-get update
pkg install wget golang curl -y
